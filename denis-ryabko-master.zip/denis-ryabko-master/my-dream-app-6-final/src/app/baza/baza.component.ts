import {Component, Input, OnInit} from '@angular/core';
import {ResDataService} from "../services/res-data.service";

@Component({
  selector: 'app-baza',
  templateUrl: './baza.component.html',
  styleUrls: ['./baza.component.scss']
})
export class BazaComponent implements OnInit {

  constructor(public resDataService:ResDataService) { }
  ngOnInit(): void {
  }
  MainType=this.resDataService.MainType;
  TypeOn(type: string){
    this.MainType=type;
  }
}
