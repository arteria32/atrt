import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BazaComponent } from './baza.component';

describe('BazaComponent', () => {
  let component: BazaComponent;
  let fixture: ComponentFixture<BazaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BazaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BazaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
