import {Component, Input, OnInit} from '@angular/core';
import {ResDataService, Reservoir} from "../../services/res-data.service";

@Component({
  selector: 'app-reservoir',
  templateUrl: './reservoir.component.html',
  styleUrls: ['./reservoir.component.scss']
})
export class ReservoirComponent implements OnInit {

  constructor(){}

  @Input() reservoir:Reservoir;

  ngOnInit(): void {
  }

}
