import {Component, Input, OnInit} from '@angular/core';
import {ResDataService, Reservoir} from "../../../services/res-data.service";

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  @Input() reservoir:Reservoir;
  constructor() { }
  ngOnInit(): void {
  }
  hgt(reservoir:Reservoir){
    return reservoir.mass/reservoir.maxmass
  }
}
