import {Component, Input, OnInit} from '@angular/core';
import {ResDataService, Reservoir} from "../../../services/res-data.service";

@Component({
  selector: 'app-tank',
  templateUrl: './tank.component.html',
  styleUrls: ['./tank.component.scss']
})
export class TankComponent implements OnInit {
  @Input() reservoir:Reservoir;
  constructor() { }
  ngOnInit(): void {
  }
  index(reservoir:Reservoir) {
    if((reservoir.mass<800)&&(reservoir.mass>200)){
      return true
    }else{
      return false
    }
  }
  hgt(reservoir:Reservoir){
    return reservoir.mass/reservoir.maxmass
  }
}
