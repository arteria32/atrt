import {Component, Input, OnInit} from '@angular/core';
import {ResDataService, Reservoir} from "../../../services/res-data.service";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit{

  constructor() { }
  @Input() reservoir:Reservoir;
  ngOnInit(): void {
  }

}
