import {Injectable} from "@angular/core";

export interface Reservoir{
  readonly maxmass:1000;
  num:number;
  type:string;
  mass:number;
  lock:boolean;
}

@Injectable({
    providedIn:'root'
  }
)

export class ResDataService{
  selectedRes=1;
  MainType=`АИ-92`;
  typeOfOil=['АИ-92','АИ-95','ДТ ЗИМНЕЕ','TC-1','МАЗУТ','ГАЗОЙЛЬ','НЕФТЬ'];
  reservoirs: Reservoir[]=[
    {maxmass:1000, num:1, type: 'АИ-92', mass:980, lock:true},
    {maxmass:1000, num:2, type: 'АИ-95', mass:680, lock:false},
    {maxmass:1000, num:3, type: 'ДТ ЗИМНЕЕ', mass:180, lock:true},
    {maxmass:1000, num:4,type: 'TC-1', mass:456, lock:false},
    {maxmass:1000, num:5,type: 'МАЗУТ', mass:125, lock:true},
    {maxmass:1000, num:6,type: 'ГАЗОЙЛЬ', mass:345, lock:true},
    {maxmass:1000, num:7,type: 'НЕФТЬ', mass:125, lock:false},
    {maxmass:1000, num:8, type: 'АИ-92', mass:351,lock:true},
  ];
}
