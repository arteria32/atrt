import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BazaComponent } from './baza/baza.component';
import { AdminComponent } from './admin/admin.component';
import { ReservoirComponent } from './baza/reservoir/reservoir.component';
import { FooterComponent } from './baza/reservoir/footer/footer.component';
import { HeaderComponent } from './baza/reservoir/header/header.component';
import { TankComponent } from './baza/reservoir/tank/tank.component';
import {ResDataService} from "./services/res-data.service";
import { ListresComponent } from './admin/listres/listres.component';
import { SetresComponent } from './admin/setres/setres.component';
import { RessetupComponent } from './admin/setres/ressetup/ressetup.component';
import {FormsModule} from "@angular/forms";

@NgModule({
  declarations: [
    AppComponent,
    BazaComponent,
    AdminComponent,
    ReservoirComponent,
    FooterComponent,
    HeaderComponent,
    TankComponent,
    ListresComponent,
    SetresComponent,
    RessetupComponent
  ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule
    ],
  providers: [ResDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
